package com.stadistic.infostadisticsms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfoStadisticsMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfoStadisticsMsApplication.class, args);
	}

}
