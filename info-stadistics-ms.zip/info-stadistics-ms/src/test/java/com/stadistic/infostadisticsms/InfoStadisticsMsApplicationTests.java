package com.stadistic.infostadisticsms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfoStadisticsMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
